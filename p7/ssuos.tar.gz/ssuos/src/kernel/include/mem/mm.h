#ifndef	   __MEM_H__
#define	   __MEM_H__

unsigned long mem_size();
void detect_mem();
void* memset(void* dst_, int value, unsigned int size);

#endif
